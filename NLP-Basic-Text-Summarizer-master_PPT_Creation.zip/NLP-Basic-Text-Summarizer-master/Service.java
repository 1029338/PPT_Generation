package ParagraphCreator;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.LinkedHashMap;

import javax.imageio.ImageIO;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class Service {

	private static String intro = "Introduction";

	public static LinkedHashMap<String, String> getParagraphs(String url) throws IOException {
		
		
		Document document = Jsoup.connect(url).get();
		Elements toRemovePronounciation = document.select("span[title^=Representation in the International Phonetic Alphabet (IPA)]");
		for (Element element : toRemovePronounciation) {
	        element.remove();
	    }
		Elements toRemove = document.select("sup");
		for (Element element : toRemove) {
	        element.remove();
	    }
		
		String html = document.html();
		
		Elements paragraphs = document.select("p");
		
		LinkedHashMap<String, String> headerParagraphs = new LinkedHashMap<>();
		Elements title = document.select("title");
		ArrayList<String> titleStr = new ArrayList<>();
		titleStr.add(title.text());
		headerParagraphs.put("title", title.text());
		
		headerParagraphs.put(intro, new String());
		
		for(Element para : paragraphs) { 
			if(para.hasText()) {
				int index=0;
				if(para.html().length()<25) {
					index=para.html().length();
				} else {
					index = html.indexOf(para.html().substring(0, 25));
				}
				String firstPart = html.substring(0, index);
				Elements headers = Jsoup.parse(firstPart).select("h1 span, h2 span");
				
				Element lastHeader = headers.last();
				if(headers.last()!=null && lastHeader.hasText()) {
					String headerContent = headerParagraphs.get(lastHeader.text());
					if(headerContent!=null && !headerContent.isEmpty()) {
						headerContent = headerContent+"\n"+"\n"+"\n"+para.text();
						headerParagraphs.put(lastHeader.text(), headerContent);
					} else {
						headerParagraphs.put(lastHeader.text(), para.text());
					}
				} else {
					String introContent = headerParagraphs.get(intro);
					introContent = introContent+para.text()+"\n"+"\n"+"\n";	
					headerParagraphs.put(intro, introContent);
				}
			}
			
		}
		
		
		
		for(String key : headerParagraphs.keySet()) {
			System.out.println("********************************************************"); 
			System.out.println(key);
			System.out.println("********************************************************");
			System.out.println(headerParagraphs.get(key));
			
			
		}
		
		return headerParagraphs;
		
	}
	
	public static BufferedImage getImages(String url) throws IOException {
		Document document = Jsoup.connect(url).get();
		Elements title = document.select("title");
		String name = title.text().split(" ")[0];
		BufferedImage image = null;
		
		Elements pngs = document.select("img[src~="+name+"]");
		if(pngs!=null && !pngs.isEmpty()) {
			Element firstImage = pngs.first();
			String imageUrl = firstImage.attr("src");
			if(!imageUrl.startsWith("http")) {
				imageUrl="https:"+imageUrl;
			}
			URL imgUrl = new URL("http://www.mkyong.com/image/mypic.jpg");
	        image = ImageIO.read(imgUrl);
		}
		
        
		return image;
		
	}

}
