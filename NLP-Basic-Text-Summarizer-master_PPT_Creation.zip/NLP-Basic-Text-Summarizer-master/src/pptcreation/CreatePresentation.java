package pptcreation;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.LinkedHashMap;

public class CreatePresentation {
	
	public static void createPresentation(String url){
		
		try {
			LinkedHashMap<String, String> wikiData = WebCrawling.getParagraphs(url);
			PPTGeneration pptGeneration = new PPTGeneration();
			for(String header : wikiData.keySet())
			{
				
				if(header.equals("title"))
				{
					String paragraph = wikiData.get(header);
					pptGeneration.generateTitleSlide(paragraph,WebCrawling.getImages(url));
				}
				else
				{
					String paragraphs = wikiData.get(header);
					ArrayList<String> summaryLines =  SummaryTool.getSummary(paragraphs);
					for(int i=0; i<summaryLines.size();i++)
					{
						ArrayList<String> lines = new ArrayList<>();
						lines.add(summaryLines.get(i));
						int nextIndex = ++i;
						if(nextIndex < summaryLines.size())	lines.add(summaryLines.get(nextIndex));
						nextIndex = ++i;
						if(nextIndex < summaryLines.size()) lines.add(summaryLines.get(nextIndex));
						pptGeneration.generateContentSlide(header, lines);
					}
				}
			}
			pptGeneration.generatePPT(wikiData.get("title")+".pptx");
		} catch (IOException | URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public CreatePresentation() {
	}
}
