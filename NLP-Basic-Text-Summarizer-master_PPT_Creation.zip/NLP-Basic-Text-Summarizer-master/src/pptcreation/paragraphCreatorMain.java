package pptcreation;
import java.io.IOException;

public class paragraphCreatorMain {
	//https://en.wikipedia.org/wiki/Shah_Rukh_Khan
	//https://en.wikipedia.org/wiki/Donald_Trump
	static WebCrawling service = new WebCrawling();

	public static void main(String[] args) throws IOException {
		//service.getParagraphs("https://en.wikipedia.org/wiki/Shah_Rukh_Khan");
		CreatePresentation.createPresentation("https://en.wikipedia.org/wiki/Shah_Rukh_Khan");
	}

}
