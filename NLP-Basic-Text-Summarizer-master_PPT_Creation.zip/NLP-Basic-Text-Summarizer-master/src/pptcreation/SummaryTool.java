package pptcreation;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import opennlp.tools.sentdetect.SentenceDetectorME;
import opennlp.tools.sentdetect.SentenceModel;
import opennlp.tools.tokenize.TokenizerME;
import opennlp.tools.tokenize.TokenizerModel;
import opennlp.tools.util.InvalidFormatException;

public class SummaryTool 
{
	
//Text into sentences
	public static ArrayList<String> splitToSentences(String content)
	{
		ArrayList<String> sent = new ArrayList<>();
		String[] tempSent = sentenceDetect.sentDetect(content);
		for(String s: tempSent)
		{
			if(s.length() >= 10)
			{
				sent.add(s);
			}
		}
		return sent;
	}
	
//Text into paragraphs
	public static String[] splitToParagraphs(String content)
	{
    	String[] mystring = content.split("\n\n\n");
		return mystring;
	}
	
	public static <T> Collection <T> intersect (Collection <? extends T> a, Collection <? extends T> b)
	{
	    Collection <T> result = new ArrayList <T> ();

	    for (T t: a)
	    {
	        if (b.remove (t)) result.add (t);
	    }

	    return result;
	}
	
//Computing the intersection(common words) between two sentences
	public static float sentenceIntersection (String sentence1, String sentence2)
	{
		String[] sent1 = tokenizer.tokenize(sentence1);
		String[] sent2 = tokenizer.tokenize(sentence2);
		
		if (sent1.length + sent2.length == 0)
			return 0;
		
		
		List<String> intersectArray = (List<String>) intersect(new ArrayList<String>(Arrays.asList(sent1)),new ArrayList<String>(Arrays.asList(sent2)));
		
		float result = ((float)(float)intersectArray.size() / ((float)sent1.length + ((float)sent2.length) / 2));
		
		return result;
	}
	
	public static String[] intersection(String[] sent1, String[] sent2)
	{
		if(sent1 == null || sent1.length == 0 || sent2 == null || sent2.length == 0)
			return new String[0];
		
		List<String> sent1List = new ArrayList<String>(Arrays.asList(sent1));
		List<String> sent2List = new ArrayList<String>(Arrays.asList(sent2));
			
		sent1List.retainAll(sent2List);
		
		String[] intersect = sent1List.toArray(new String[0]);
		
		return intersect;
	}
	
	public static String formatSentence(String sentence)
	{
		return sentence;
	}

	public static ArrayList<String> getBestsentenceFromParagraph(String paragraph,int percentage)
	{
		ArrayList<String> sentences = splitToSentences(formatSentence(paragraph));
		
		if(sentences == null || sentences.size() <= 2)
			return null;
		
		float[][] intersectionMatrix = getSentenceIntersectionMatrix(sentences);
		
		float[] sentenceScores = getSentenceScores(sentences, intersectionMatrix);
		
		float high=sentenceScores[0],low=sentenceScores[0];
		for(float score:sentenceScores)
		{
			if(score > high)
			{
				high = score;
			}
			if(score < low)
			{
				low = score;
			}
		}
		//System.out.println("Highest: "+ high +" Lowest: "+low);
		
		float lowerBound = computeLowerBound(high,low,percentage);
		//System.out.println("LowerBound: "+ lowerBound );
		
		return getBestSentence(sentences,  sentenceScores, lowerBound);
	}
	
	public static float computeLowerBound (float high, float low, int percentage)
	{
		float temp = ( float )( (high - low) * ( ( float )(100 - percentage) / 100 ) );
		return low + temp;
	}
	public static float[][] getSentenceIntersectionMatrix(ArrayList<String> sentences)
	{
		//Split the content in to sentences
		
		
		int n = sentences.size();
		
		float[][] intersectionMatrix= new float[n][n];
		
		for(int i = 0; i< n; i++)
		{
			for(int j = 0; j< n; j++)
			{
				try
				{
					if(i == j)
					{
						//intersectionMatrix[i][j] = 0;
						//System.out.println(intersectionMatrix[i][j]);
						continue;
					}
					
				intersectionMatrix[i][j] = sentenceIntersection(sentences.get(i), sentences.get(j));
				//System.out.println(intersectionMatrix[i][j]);
				}
				catch(Exception e)
				{
					System.out.println(e.getMessage());
				}
			}
		}
		
		//Build the sentence dictionary
		//The score of a sentence is the sum of all its intersections
		
		return intersectionMatrix;
	}
	
	public static float[] getSentenceScores(ArrayList<String> sentences, float[][] scores)
	{
		float[] scoresReturn = new float[sentences.size()];
		
		for(int i=0; i<sentences.size(); i++)
		{
			float sentenceScore = 0;
			for(int j=0; j<scores[i].length; j++)
			{
				if(i==j)
					continue;
				sentenceScore += scores[i][j];
			}
			scoresReturn[i] = sentenceScore;
			//System.out.println(scoresReturn[i]);
		}
		
		return scoresReturn;
	}
	
	public static ArrayList<String> getBestSentence(ArrayList<String> sentences, float[] scores, float lowerBound)
	{	
		ArrayList<String> bestSentences = new ArrayList<>();
//		for(int i=0; i<sentences.size() && i < scores.length;i++)
//		{
//			System.out.println(sentences.get(i) + " Score: "+ scores[i] );
//		}
//		System.out.println();
		
		for(int i=0;i<scores.length;i++)
		{
			if(scores[i] >= lowerBound)
			{
				bestSentences.add(sentences.get(i));
			}
		}
		
		return bestSentences;
		//return sentences[getMaxIndex(scores)];
		
	}
	
	public static int getMaxIndex(float[] array)
	{
		int maxIndex = 0;
		float max = -1;
		for(int i=0; i<array.length; i++)
		{
			if(array[i]>max)
			{
				max = array[i];
				maxIndex = i;
			}
			
		}
		return maxIndex;
	}
	
	public static TokenizerME tokenizer;
	public static SentenceDetectorME sentenceDetect;
	public static SummaryTool Instance;
	
	public SummaryTool()
	{
		initialize();
	}
	
	public void initialize()
	{
		InputStream sentenceModelIS = this.getClass().getResourceAsStream("../Data/en-sent.bin"); //new FileInputStream("src/Data/en-sent.bin");
		SentenceModel model;
		try 
		{	
			model = new SentenceModel(sentenceModelIS);
			sentenceDetect = new SentenceDetectorME(model);
		} catch (InvalidFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		InputStream tokenizerModelIS = this.getClass().getResourceAsStream("../Data/en-token.bin"); //new FileInputStream("src/Data/en-token.bin");
		TokenizerModel tokenModel;
		try 
		{	
			tokenModel = new TokenizerModel(tokenizerModelIS);
		    tokenizer = new TokenizerME(tokenModel);
		} catch (InvalidFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	
	public static ArrayList<String> getSummary(String paragraph)
	{
		Instance = new SummaryTool();
		String[] paragraphs = splitToParagraphs(paragraph);
		StringBuilder summary = new StringBuilder();
		
		//System.out.println("No of Para: "+paragraphs.length);
		
		ArrayList<String> summarySentences = new ArrayList<>(); 
		
		int index=1;
		for(String p : paragraphs)
		{
			summary.append("Paragraph "+index);
			summary.append("\n");
			
			ArrayList<String> bestSentences = getBestsentenceFromParagraph(p,20);
			
			if(bestSentences != null && bestSentences.size() != 0)
			{
				//System.out.println(bestSentences.size());
				for(String sentence : bestSentences)
				{
					if(sentence != null && sentence.length() > 0)
					{
						summarySentences.add(sentence);
						summary.append(sentence);
						summary.append("\n");
					}
				}
			}
			index++;
			summary.append("\n");
		}
//		System.out.println("\n");
//		System.out.println("Final Summary:");
//		System.out.println(summary);
		
		return summarySentences;
	}
	
//	@SuppressWarnings("resource")
//	public static void main(String[] args) 
//	{
//		@SuppressWarnings("unused")
//		String title = "this is a title";
//		String content = "";
//		
//		Instance = new SummaryTool();
//		
//		 try {
//			 
//			 content = new Scanner(new File(args[0])).useDelimiter("\\Z").next();
//			
//		 }
//		 catch (FileNotFoundException e) {
//		        e.printStackTrace();
//		    }		 
//		
//		ArrayList<String> summary1 = getSummary(content);
////		
////		String[] paragraphs = splitToParagraphs(content);
////		StringBuilder summary = new StringBuilder();
////		System.out.println("No of Para: "+paragraphs.length);
////		int index=1;
////		for(String p : paragraphs)
////		{
////			summary.append("Paragraph "+index);
////			summary.append("\n");
////			ArrayList<String> bestSent = getBestsentenceFromParagraph(p,40);
////			if(bestSent != null && bestSent.size() != 0)
////			{
////				System.out.println(bestSent.size());
////				for(String sentence : bestSent)
////				{
////					if(sentence != null && sentence.length() > 0)
////					{
////						//System.out.println(sentence);
////						summary.append(sentence);
////						summary.append("\n");
////					}
////				}
////			}
////			index++;
////			summary.append("\n");
////		}
////		System.out.println("\n");
////		System.out.println("Final Summary:");
////		System.out.println(summary);
//	}
}


