package pptcreation;
import java.awt.Dimension;
import java.awt.geom.Rectangle2D;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.sl.usermodel.PictureData.PictureType;
import org.apache.poi.sl.usermodel.TextParagraph.TextAlign;
import org.apache.poi.xslf.usermodel.XMLSlideShow;
import org.apache.poi.xslf.usermodel.XSLFPictureData;
import org.apache.poi.xslf.usermodel.XSLFPictureShape;
import org.apache.poi.xslf.usermodel.XSLFSlide;
import org.apache.poi.xslf.usermodel.XSLFSlideLayout;
import org.apache.poi.xslf.usermodel.XSLFSlideMaster;
import org.apache.poi.xslf.usermodel.XSLFTextParagraph;
import org.apache.poi.xslf.usermodel.XSLFTextRun;
import org.apache.poi.xslf.usermodel.XSLFTextShape;


public class PPTGeneration {
	
	XMLSlideShow ppt;
	List<XSLFSlideMaster> slideMaster;
	XSLFSlideLayout titleLayout, contentLayout, pictureLayout;
	
	File file;
	FileOutputStream out;

	public PPTGeneration() throws FileNotFoundException, IOException {
		
		File file = new File("theme.pptx");
	    ppt = new XMLSlideShow(new FileInputStream(file));
		
		//creating presentation
		//ppt = new XMLSlideShow();
		
		//getting the slide master object
		slideMaster = ppt.getSlideMasters();
		
		
		//get the desired slide layout 
		titleLayout = slideMaster.get(0).getLayout("Title Slide");
		//		.getLayout(SlideLayout.TITLE);
		
		/*System.out.println("****************************************************");
		System.out.println("PPT Background: "+slideMaster.get(0).getBackground());
		System.out.println("TitleL Theme: "+titleLayout.getTheme());
		System.out.println("TitleL Background: "+titleLayout.getBackground());	
		System.out.println("****************************************************");*/
		
		contentLayout = slideMaster.get(0).getLayout("Title And Content");
				//getLayout(SlideLayout.TITLE_AND_CONTENT);
	}

	public void generateTitleSlide(String title, FileInputStream image) throws IOException
	{
		//creating a slide with title layout
		XSLFSlide slide = this.ppt.createSlide(this.titleLayout);
		
		//selecting the place holder in it 
	    XSLFTextShape titleShape = slide.getPlaceholder(0);
	    
	    titleShape.setText(title);
	  	//slideTitle.setText(title);
	    //slideTitle.setStrokeStyle(20);
	    
	    //Removing 2 element of title slide.
	    if(image!=null) {
	    	XSLFTextShape bodyOfTitleSlide = slide.getPlaceholder(1);
		    slide.removeShape(bodyOfTitleSlide);
		    XSLFPictureData pictureData = ppt.addPicture(image, PictureType.PNG);
		    XSLFPictureShape picture = slide.createPicture(pictureData);
		    Dimension pgsize = ppt.getPageSize();
		    picture.setAnchor(new Rectangle2D.Float(pgsize.width/3, pgsize.width/3+50, pgsize.width/3, pgsize.width/3));
	    }
	    
	    
	}
	
	public void generateContentSlide(String header, ArrayList<String> summaryLines) {

		if (header != null && summaryLines != null) {
			XSLFSlide slide = this.ppt.createSlide(this.contentLayout);

			XSLFTextShape slideHeader = slide.getPlaceholder(0);

			// setting the title init
			slideHeader.clearText();
			slideHeader.setText(header);

			XSLFTextShape slideBody = slide.getPlaceholder(1);

			// clear the existing text in the slide
			slideBody.clearText();

			// adding new paragraph
			for (String sentence : summaryLines) {
				if (sentence != null && sentence.length() > 0) {
					XSLFTextParagraph para = slideBody.addNewTextParagraph();
					para.setTextAlign(TextAlign.JUSTIFY);
					XSLFTextRun line =  para.addNewTextRun();
					line.setFontSize((double) 24);
					line.setText(sentence);
				}
			}
		}
	}
	
	public void generatePPT(String fileName) throws IOException {
		// create a file object
		this.file = new File(fileName);
		this.out = new FileOutputStream(this.file);

		// save the changes in a PPt document
		this.ppt.write(out);
		System.out.println("slide cretated successfully");
		this.ppt.close();
		this.out.close();

	}
	
//	public static void main(String args[]) throws IOException {
//	      
//	}

}
